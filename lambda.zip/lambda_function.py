cat <<EOF > lambda_function.py
import boto3
import os

ses = boto3.client('ses', region_name=os.environ['AWS_REGION'])

def lambda_handler(event, context):
    try:
        response = ses.send_email(
            Source=os.environ['SOURCE_EMAIL'],
            Destination={'ToAddresses': [os.environ['DEST_EMAIL']]},
            Message={
                'Subject': {'Data': 'Automated Email from Lambda'},
                'Body': {'Text': {'Data': 'This is an automated email triggered by an AWS Lambda function.'}}
            }
        )
        return {
            'statusCode': 200,
            'body': f"Email sent successfully. SES Message ID: {response['MessageId']}"
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': f"Error sending email: {str(e)}"
        }
